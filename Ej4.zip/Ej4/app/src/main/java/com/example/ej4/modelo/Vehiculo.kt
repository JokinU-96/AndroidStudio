package com.example.ej4.modelo

class Vehiculo(
    var tipoVehiculo: String,
    var marcaVehiculo: String,
    var cilindradaVehiculo: Double
) {

}